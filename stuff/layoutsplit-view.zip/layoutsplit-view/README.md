# Layout--split-view

A Pen created on CodePen.io. Original URL: [https://codepen.io/rdierckx/pen/GvzMBb](https://codepen.io/rdierckx/pen/GvzMBb).

