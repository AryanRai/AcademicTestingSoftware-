# ScrollTrigger - with user highligter 

A Pen created on CodePen.io. Original URL: [https://codepen.io/aryanrai/pen/OJBVbeo](https://codepen.io/aryanrai/pen/OJBVbeo).

Uses the GSAP ScrollTrigger plugin to highlight text that scroll into view.

See a version using the Intersection Observer API: <a href="https://codepen.io/hexagoncircle/pen/OJMXZzB">https://codepen.io/hexagoncircle/pen/OJMXZzB</a>