# Bootstrap Quiz

A Pen created on CodePen.io. Original URL: [https://codepen.io/martinaJ/pen/MeKKbZ](https://codepen.io/martinaJ/pen/MeKKbZ).

